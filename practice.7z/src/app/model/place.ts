// model to store place object
export class Place{
_id: string;
id: number;
name: string;
type: string;
rating: number;
latitude: number;
longitude: number;
 }